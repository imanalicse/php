http://localhost:15672/
username = guest
password = guest

rabbitmq-plugins enable rabbitmq_management

<?php
